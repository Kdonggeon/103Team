package com.team103;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team103BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
