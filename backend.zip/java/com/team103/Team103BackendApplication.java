package com.team103;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Team103BackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(Team103BackendApplication.class, args);
    }
}
