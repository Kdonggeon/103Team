package com.team103.dto;

public class SignupRequest {

}
