var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__16862569._.js")
R.c("server/chunks/ea5b2_next_dist_434783d9._.js")
R.c("server/chunks/ea5b2_next_dist_c6cbe10b._.js")
R.c("server/chunks/ea5b2_next_0c81f80f._.js")
R.m(2263)
R.m(85282)
module.exports=R.m(85282).exports
