var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/signup/student/route.js")
R.c("server/chunks/[root-of-the-server]__7fe037a8._.js")
R.c("server/chunks/ea5b2_next_ab25aede._.js")
R.m(81976)
R.m(287)
module.exports=R.m(287).exports
