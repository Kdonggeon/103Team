var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/signup/teacher/route.js")
R.c("server/chunks/[root-of-the-server]__adaa9628._.js")
R.c("server/chunks/ea5b2_next_ab25aede._.js")
R.m(22586)
R.m(74246)
module.exports=R.m(74246).exports
