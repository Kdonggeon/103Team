var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/signup/director/route.js")
R.c("server/chunks/[root-of-the-server]__8311a0c8._.js")
R.c("server/chunks/ea5b2_next_ab25aede._.js")
R.m(572)
R.m(56065)
module.exports=R.m(56065).exports
