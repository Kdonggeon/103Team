var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/signup/parent/route.js")
R.c("server/chunks/[root-of-the-server]__a849247d._.js")
R.c("server/chunks/ea5b2_next_ab25aede._.js")
R.m(58831)
R.m(90717)
module.exports=R.m(90717).exports
