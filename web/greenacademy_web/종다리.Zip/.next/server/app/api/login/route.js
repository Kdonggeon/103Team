var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/login/route.js")
R.c("server/chunks/[root-of-the-server]__0d0e8671._.js")
R.c("server/chunks/ea5b2_next_ab25aede._.js")
R.m(37178)
R.m(56196)
module.exports=R.m(56196).exports
