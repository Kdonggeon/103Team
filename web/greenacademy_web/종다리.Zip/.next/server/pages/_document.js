var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__b83a551d._.js")
R.c("server/chunks/ssr/[root-of-the-server]__4b8cc589._.js")
R.m(14724)
module.exports=R.m(14724).exports
