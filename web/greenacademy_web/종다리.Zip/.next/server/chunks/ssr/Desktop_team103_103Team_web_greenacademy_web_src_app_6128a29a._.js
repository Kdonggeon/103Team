module.exports=[21771,a=>{a.v("/_next/static/media/favicon.af2dca7d.ico")},22110,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(21771).default,width:48,height:48}}];

//# sourceMappingURL=Desktop_team103_103Team_web_greenacademy_web_src_app_6128a29a._.js.map