__turbopack_load_page_chunks__("/_error", [
  "static/chunks/a0dfeee8e4e85158.js",
  "static/chunks/99680899cab807a3.js",
  "static/chunks/turbopack-7ada00af5504b781.js"
])
