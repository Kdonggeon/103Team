__turbopack_load_page_chunks__("/_app", [
  "static/chunks/0ec383aece114e61.js",
  "static/chunks/99680899cab807a3.js",
  "static/chunks/turbopack-855fbd32d448398e.js"
])
