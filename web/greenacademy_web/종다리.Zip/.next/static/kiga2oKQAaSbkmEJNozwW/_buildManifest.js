self.__BUILD_MANIFEST = {
  "/_error": [
    "./static/chunks/2b63c3919ae89a04.js"
  ],
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/backend/:path*"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()