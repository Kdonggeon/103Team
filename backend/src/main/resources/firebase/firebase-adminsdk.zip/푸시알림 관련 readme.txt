보안상의 이유로 이 푸시알림 관련 파일이
깃허브에  올라가지 않습니다 

C:\project\103Team-sub\backend\src\main\resources\firebase(현재자리)에 
firebase-adminsdk.json 넣으면 푸시알림이 작동합니다.